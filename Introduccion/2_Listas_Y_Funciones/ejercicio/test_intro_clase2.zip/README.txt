### README

Chequear que la carpeta test este en el mismo path que la notebook que se esta ejecutantdo


